<template>
  <div id="app">
    <RecipeSearch />
  </div>
</template>

<script>
import RecipeSearch from './RecipeSearch.vue';

export default {
  components: {
    RecipeSearch
  }
};
</script>