// app.js

// Function to handle registration
function register(event) {
    event.preventDefault();

    const username = document.getElementById('reg-username').value;
    const password = document.getElementById('reg-password').value;
    const email = document.getElementById('reg-email').value;

    fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password, email })
    })
        .then(response => response.text())
        .then(data => {
            alert(data);
            window.location.href = 'index.html';
        })
        .catch(error => console.error('Error:', error));
}

// Function to handle login
function login(event) {
    event.preventDefault();

    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;

    fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    })
        .then(response => {
            if (response.ok) {
                window.location.href = 'main.html';
            } else {
                return response.text().then(text => { throw new Error(text) });
            }
        })
        .catch(error => {
            document.getElementById('login-error').textContent = error.message;
        });
}
