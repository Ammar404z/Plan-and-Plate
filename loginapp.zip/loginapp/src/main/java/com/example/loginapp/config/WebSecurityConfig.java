//package com.example.loginapp.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.web.SecurityFilterChain;
//
//
//@Configuration
//@EnableWebSecurity
//public class WebSecurityConfig {
//    @Bean
//    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//        http
//                .csrf().disable() // Disable CSRF for simplicity
//                .authorizeRequests()
//                .antMatchers("/", "/index.html", "/register.html", "/styles.css", "/app.js", "/api/auth/**").permitAll()
//                .anyRequest().authenticated();
//
//        return http.build();
//    }
//
//    // Optionally, configure an in-memory authentication provider
//    @Bean
//    public void configureAuthentication(AuthenticationManagerBuilder auth) throws Exception {
//        // Define in-memory authentication or other custom user details service here if needed
//    }
//}